import requests

class BadRequest(Exception):
    '''When 400 hits in'''
    pass

class InternalServerError(Exception):
    '''When 500 hits in'''
    pass

class InvalidURL(Exception):
    '''When Invalid url is given'''
    pass

class ContentTooLarge(Exception):
    '''When Given content bigger than 2000'''
    pass

class ConnectionError(Exception):
    '''When Connection error accures such as no inter net etc.'''
    pass

class SchemaError(Exception):
    '''When schema not right'''
    pass

class NoSuchID(Exception):
    '''When id is not found in urlr'''
    pass

class AlreadyExists(Exception):
    '''When id is already exists in urlr'''
    pass

class HTTPError(Exception):
    '''When other HTTP error accures'''
    pass

class NotJSON(Exception):
    '''If customJSON is not a dictionary'''
    pass

urlr = {}

def init(url:str, id=1):
    '''specify webhook url and id (Deafult 1)'''
    global urlr
    if not url:
        raise InvalidURL(f"MUST BE VALID URL FOR ID {id}")
    if id in urlr:
        raise AlreadyExists(f"{id} ALREADY EXSISTS")
    urlr[id] = url

def send(content:str, ids, statCode:bool=False, flush:bool = False, customJSON = {}):
    '''Send content to specified webhook'''
    global urlr
    if not urlr:
        raise InvalidURL("FIRST SPECIFY URL USING init(url, id) MODULE")
    if len(content) > 2000:
        raise ContentTooLarge(f"TOO LARGE CONTENT FOR {ids}")
    data = {
        "content":content
    }
    if not isinstance(customJSON, dict):
        raise NotJSON("customJSON PARAMETR IS NOT DICTIONARY. FOR id{ids}")
    if customJSON:
        data = customJSON
    if urlr.get(ids) == None:
        raise NoSuchID(f"NOT FOUND {ids}")
    try:
        a = requests.post(urlr.get(ids), json=data)
    except requests.exceptions.ConnectionError:
        raise ConnectionError(f"CONNECTION ERROR FOR id={ids}. PLEASE CHECK CONNETCTION AND URL FOR ANY ERRORS")
    except requests.exceptions.MissingSchema:
        raise SchemaError(f"MUST BE WITH https:// OR http:// IF HTTPS NOT SUPPORTED. FOR id={ids}")
    
    if a.status_code == 400:
        raise BadRequest(f"BAD REQUEST (HTTP ERROR: 400). FOR id{ids}")
    
    if a.status_code == 500:
        raise InternalServerError(f"INTERNAL SERVER ERROR (HTTP ERROR: 500). FOR id={ids}")

    if not a.ok:
        raise HTTPError(f"SERVER RETURNED NOT 2xx RESPONSE {a.status_code}. FOR id={ids}")
    
    if statCode:
        print(a.status_code, f"FOR {ids}")

    if flush:
        if a.text == "":
            print(f"NOTHING FROM SERVER FOR {ids}")
        else:
            print(a.text, f"FOR {ids}")